Dependencies

networkx           2.6.3
scikit-learn       0.24.2
scikit-network     0.24.0
torch              1.10.1
torch-cluster      1.6.0
torch-geometric    2.0.4
torch-scatter      2.0.9
torch-sparse       0.6.13
torchaudio         0.10.1
torchvision        0.11.2

pagekage metis

The dataset includes the some datasets used in this paper.